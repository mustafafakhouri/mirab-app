/* مِعْراب — منطق التطبيق */
(function(){
  "use strict";
  var D = window.MIRAB_DATA;
  var S = loadState();

  var CASE_LABEL = { raf:"مرفوع (أو محلّ رفع)", nasb:"منصوب (أو محلّ نصب)", jarr:"مجرور (أو محلّ جرّ)", jazm:"مجزوم", mabni:"مبنيّ / حرف لا محلّ له" };
  var CASE_COLOR = { raf:"#2e8b57", nasb:"#c0392b", jarr:"#2563c9", jazm:"#d98318", mabni:"#6b7280" };

  // ---------- state ----------
  function loadState(){
    try{ var s = JSON.parse(localStorage.getItem("mirab_state")||"{}");
      return { points:s.points||0, done:s.done||{}, mistakes:s.mistakes||[], streakDay:s.streakDay||null, streak:s.streak||0 };
    }catch(e){ return {points:0,done:{},mistakes:[],streakDay:null,streak:0}; }
  }
  function save(){ try{ localStorage.setItem("mirab_state", JSON.stringify(S)); }catch(e){} }
  function touchStreak(){
    var today = new Date().toISOString().slice(0,10);
    if(S.streakDay===today) return;
    var y = new Date(Date.now()-86400000).toISOString().slice(0,10);
    S.streak = (S.streakDay===y) ? (S.streak+1) : 1;
    S.streakDay = today; save();
  }

  // ---------- helpers ----------
  function el(tag, cls, html){ var e=document.createElement(tag); if(cls)e.className=cls; if(html!=null)e.innerHTML=html; return e; }
  function $(s){ return document.querySelector(s); }
  function totalWords(){ var n=0; D.surahs.forEach(function(s){ s.verses.forEach(function(v){ n+=v.words.length; }); }); return n; }
  function doneCount(){ return Object.keys(S.done).length; }

  // ---------- header ----------
  function renderStats(){
    $("#stat-points").textContent = S.points;
    $("#stat-streak").textContent = S.streak;
    $("#stat-prog").textContent = doneCount()+"/"+totalWords();
  }

  // ---------- home ----------
  function renderHome(){
    var leg = $("#legend"); leg.innerHTML="";
    D.legend.forEach(function(l){
      var c = el("div","chip");
      c.appendChild(el("span","dot")).style.background=l.color;
      c.appendChild(el("span",null,"<b>"+l.label+"</b> — "+l.hint));
      leg.appendChild(c);
    });
    var pb = $("#home-prog span"); pb.style.width = (totalWords()? (doneCount()/totalWords()*100):0)+"%";
    $("#home-prog-txt").textContent = "أعربتَ "+doneCount()+" كلمة من "+totalWords();
  }

  // ---------- learn ----------
  var LEARN = [
    { h:"١) كل كلمة: اسم أو فعل أو حرف", p:"الاسمُ ما دلّ على مُسمّى (رجل، كتاب، الله)، والفعلُ ما دلّ على حدثٍ وزمن (كتبَ، يكتبُ، اكتبْ)، والحرفُ ما لا معنى له إلا مع غيره (في، من، إنّ، لم)." },
    { h:"٢) الجملة: اسمية أو فعلية", p:"الاسمية تبدأ باسم وأصلها (مبتدأ + خبر): «اللهُ الصمدُ». والفعلية تبدأ بفعل وأصلها (فعل + فاعل + مفعول): «جاء نصرُ اللهِ»." },
    { h:"٣) الحالات: رفع، نصب، جرّ، جزم", p:"المرفوع علامته الضمة (الفاعل، المبتدأ، الخبر)، والمنصوب الفتحة (المفعول، الحال)، والمجرور الكسرة (بعد حرف الجرّ أو بالإضافة)، والجزم للأفعال المضارعة علامته السكون." },
    { h:"٤) العلامة قد تنوب عنها علامة", p:"ليست العلامة دائمًا الأصل: جمع المؤنث السالم يُنصب بالكسرة («الصالحاتِ»)، والأفعال الخمسة تُرفع بثبوت النون («يدخلون»). فانظر النوع قبل الحكم." },
    { h:"٥) السؤال الثلاثي", p:"لإعراب أي كلمة اسأل: ما نوعها؟ ثم ما حالتها الإعرابية/وظيفتها؟ ثم ما علامتها؟ كرّرها حتى تصير سليقة." }
  ];
  function renderLearn(){
    var box=$("#learn-list"); box.innerHTML="";
    LEARN.forEach(function(c){ var d=el("div","card"); d.innerHTML="<h2>"+c.h+"</h2><p>"+c.p+"</p>"; box.appendChild(d); });
  }

  // ---------- practice: surah list ----------
  function renderSurahList(){
    var g=$("#surah-grid"); g.innerHTML="";
    D.surahs.forEach(function(s){
      var tot=0,dn=0; s.verses.forEach(function(v){ v.words.forEach(function(_,i){ tot++; }); });
      s.verses.forEach(function(v,vi){ v.words.forEach(function(_,wi){ if(S.done[s.id+"-"+vi+"-"+wi]) dn++; }); });
      var c=el("div","surah-card");
      c.innerHTML="<div class='n'>سورة "+s.name+"</div><div class='o'>الترتيب "+s.order+" · "+dn+"/"+tot+" كلمة</div>";
      c.onclick=function(){ openSurah(s.id); };
      g.appendChild(c);
    });
    $("#surah-view").style.display="none";
    $("#surah-grid").style.display="grid";
    $("#practice-intro").style.display="block";
  }

  var curSurah=null;
  function openSurah(id){
    curSurah = D.surahs.filter(function(s){return s.id===id;})[0];
    $("#surah-grid").style.display="none";
    $("#practice-intro").style.display="none";
    var v=$("#surah-view"); v.style.display="block"; v.innerHTML="";

    var top=el("div","toolbar");
    var back=el("button","btn ghost","→ كل السور"); back.onclick=renderSurahList; top.appendChild(back);
    var tgl=el("button","btn nav","إظهار الألوان");
    tgl.onclick=function(){ var w=$("#ayat-wrap"); w.classList.toggle("colors-on"); tgl.textContent=w.classList.contains("colors-on")?"إخفاء الألوان":"إظهار الألوان"; };
    top.appendChild(tgl);
    v.appendChild(top);

    var head=el("div","card"); head.innerHTML="<h2>سورة "+curSurah.name+"</h2><p class='muted'>"+curSurah.intro+"</p><p class='muted'>اضغط أي كلمة لتُعربها بـ«السؤال الثلاثي».</p>";
    v.appendChild(head);

    var wrap=el("div"); wrap.id="ayat-wrap";
    curSurah.verses.forEach(function(verse,vi){
      var vc=el("div","verse");
      var ay=el("div","ayah");
      verse.words.forEach(function(word,wi){
        var key=curSurah.id+"-"+vi+"-"+wi;
        var sp=el("span","word"+(S.done[key]?" done":""));
        sp.setAttribute("data-cat",word.cat);
        sp.textContent=word.w;
        sp.onclick=function(){ openQuiz(curSurah,vi,wi,sp); };
        ay.appendChild(sp); ay.appendChild(document.createTextNode(" "));
      });
      vc.appendChild(ay);
      var br=el("div","bridge"); br.innerHTML="<b>جسر المعنى:</b> "+verse.bridge;
      vc.appendChild(br);
      wrap.appendChild(vc);
    });
    v.appendChild(wrap);
  }

  // ---------- quiz modal ----------
  var quizCtx=null;
  function shuffle(a){ a=a.slice(); for(var i=a.length-1;i>0;i--){ var j=Math.floor(Math.random()*(i+1)); var t=a[i];a[i]=a[j];a[j]=t; } return a; }

  function openQuiz(surah,vi,wi,spanEl){
    var word=surah.verses[vi].words[wi];
    quizCtx={surah:surah,vi:vi,wi:wi,word:word,span:spanEl,step:1,errored:false};
    $("#m-target").textContent=word.w;
    $("#m-feedback").textContent=""; $("#m-feedback").className="feedback";
    $("#m-reveal").classList.remove("show");
    renderStep1();
    $("#overlay").classList.add("show");
  }
  function renderStep1(){
    $("#m-qlabel").textContent="السؤال ١: ما نوع هذه الكلمة؟";
    var opts=$("#m-opts"); opts.innerHTML="";
    ["اسم","فعل","حرف"].forEach(function(o){
      var b=el("button","opt",o);
      b.onclick=function(){ answer(b,o===quizCtx.word.type,renderStep2); };
      opts.appendChild(b);
    });
  }
  function renderStep2(){
    $("#m-feedback").textContent=""; $("#m-feedback").className="feedback";
    $("#m-qlabel").textContent="السؤال ٢: ما حالتها الإعرابية؟";
    var opts=$("#m-opts"); opts.innerHTML="";
    var choices = shuffle(["raf","nasb","jarr","jazm","mabni"]);
    choices.forEach(function(cat){
      var b=el("button","opt",CASE_LABEL[cat]);
      b.onclick=function(){ answer(b,cat===quizCtx.word.cat,revealFull); };
      opts.appendChild(b);
    });
  }
  function answer(btn,correct,next){
    var fb=$("#m-feedback");
    if(correct){
      btn.classList.add("correct"); fb.textContent="أحسنت! إجابة صحيحة."; fb.className="feedback ok";
      disableOpts();
      setTimeout(next,650);
    } else {
      btn.classList.add("wrong"); fb.textContent="ليست هذه. حاول مرة أخرى."; fb.className="feedback no";
      quizCtx.errored=true;
      btn.disabled=true;
    }
  }
  function disableOpts(){ var b=$("#m-opts").querySelectorAll("button"); for(var i=0;i<b.length;i++)b[i].disabled=true; }

  function revealFull(){
    var w=quizCtx.word;
    $("#m-qlabel").textContent="الإعراب الكامل:";
    $("#m-opts").innerHTML="";
    var r=$("#m-reveal");
    r.innerHTML="<span class='tag' style='background:"+CASE_COLOR[w.cat]+"'>"+({raf:"مرفوع",nasb:"منصوب",jarr:"مجرور",jazm:"مجزوم",mabni:"مبنيّ/حرف"}[w.cat])+"</span>"
      +"<div class='full'>"+w.full+"</div>";
    r.classList.add("show");
    // scoring (once per word)
    var key=quizCtx.surah.id+"-"+quizCtx.vi+"-"+quizCtx.wi;
    if(!S.done[key]){
      S.done[key]=true;
      S.points += quizCtx.errored?3:5;
      touchStreak();
    }
    if(quizCtx.errored){ pushMistake(quizCtx); }
    quizCtx.span.classList.add("done");
    save(); renderStats();
    // add a close/continue button
    var fb=$("#m-feedback"); fb.className="feedback ok"; fb.textContent= quizCtx.errored? "راجِعها لاحقًا في قسم المراجعة." : "ممتاز! +5 نقاط.";
  }
  function pushMistake(ctx){
    var key=ctx.surah.id+"-"+ctx.vi+"-"+ctx.wi;
    for(var i=0;i<S.mistakes.length;i++){ if(S.mistakes[i].key===key) return; }
    S.mistakes.push({key:key,w:ctx.word.w,full:ctx.word.full,surah:ctx.surah.name,cat:ctx.word.cat});
    save();
  }
  function closeModal(){ $("#overlay").classList.remove("show"); if(curSurah){ /* refresh counts */ } }

  // ---------- review ----------
  function renderReview(){
    var box=$("#review-list"); box.innerHTML="";
    if(!S.mistakes.length){ box.appendChild(el("div","empty","لا أخطاء محفوظة بعد — أحسنت! تدرّب أكثر لتظهر هنا الكلمات التي تحتاج مراجعة.")); return; }
    S.mistakes.forEach(function(m){
      var it=el("div","rev-item");
      it.innerHTML="<div><div class='wtxt'>"+m.w+"</div><div class='muted' style='font-size:13px'>سورة "+m.surah+"</div></div>";
      var right=el("div");
      var tag=el("span","tag"); tag.style.background=CASE_COLOR[m.cat]; tag.style.color="#fff"; tag.style.padding="2px 10px"; tag.style.borderRadius="20px"; tag.style.fontSize="12px";
      tag.textContent={raf:"مرفوع",nasb:"منصوب",jarr:"مجرور",jazm:"مجزوم",mabni:"مبنيّ/حرف"}[m.cat];
      var btn=el("button","btn ghost","الإعراب"); btn.style.padding="6px 12px"; btn.style.fontSize="13px"; btn.style.marginright="8px";
      btn.onclick=function(){ alert(m.w+"\n\n"+m.full); };
      right.appendChild(tag); right.appendChild(btn);
      it.appendChild(right);
      box.appendChild(it);
    });
    var clr=el("button","btn ghost","مسح قائمة المراجعة"); clr.style.marginTop="10px";
    clr.onclick=function(){ if(confirm("مسح كل الكلمات من المراجعة؟")){ S.mistakes=[]; save(); renderReview(); } };
    box.appendChild(clr);
  }

  // ---------- tabs ----------
  function show(view){
    var vs=document.querySelectorAll(".view"); for(var i=0;i<vs.length;i++)vs[i].classList.remove("active");
    $("#view-"+view).classList.add("active");
    var bs=document.querySelectorAll("nav.tabs button"); for(var j=0;j<bs.length;j++)bs[j].classList.toggle("active",bs[j].getAttribute("data-v")===view);
    if(view==="home")renderHome();
    if(view==="learn")renderLearn();
    if(view==="practice")renderSurahList();
    if(view==="review")renderReview();
    window.scrollTo(0,0);
  }

  // ---------- init ----------
  document.addEventListener("DOMContentLoaded",function(){
    var bs=document.querySelectorAll("nav.tabs button");
    for(var i=0;i<bs.length;i++){ (function(b){ b.onclick=function(){ show(b.getAttribute("data-v")); }; })(bs[i]); }
    $("#go-practice").onclick=function(){ show("practice"); };
    $("#m-x").onclick=closeModal;
    $("#overlay").onclick=function(e){ if(e.target===$("#overlay")) closeModal(); };
    renderStats(); show("home");
  });
})();
